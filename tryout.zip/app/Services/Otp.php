<?php

namespace App\Services;


/**
 *
 */
class Otp
{

   public static function InitializeOtpDisable()
   {

   }

   public static function finalizeOtpDisable()
   {
      
   }
}
