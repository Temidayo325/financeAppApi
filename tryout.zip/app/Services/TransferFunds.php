<?php

namespace App\Services;



/**
 *
 */
class TransferFunds
{

   public static function initializeTransfer()
   {

   }

   public static function finalizeTransfer()
   {

   }
}
