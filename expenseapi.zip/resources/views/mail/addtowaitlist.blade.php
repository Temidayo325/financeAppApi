@component('mail::message')
# Welcome to ExpenseX

Of course I don't always follow through on my money plans, who hasan't done it hands in the air! No hands?

Let's get the try this new approach and see how far we can all go in achieving our money goals.

Looking forward to working with you Soonest


Thanks,<br>
Kelvin From ExpenseX
@endcomponent
