@component('mail::message')
# Welcome to ExpenseX {{ $name }}

You are welcome to comrade. let's get this started shall we


Thanks,<br>
{{ config('app.name') }}
@endcomponent
