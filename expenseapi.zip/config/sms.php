<?php

return [
  'kudisms' => [
    'api_url' => env('KUDI_SMS_API_URL'),
    'username' => env('KUDI_SMS_USERNAME'),
    'password' => env('KUDI_SMS_PASSWORD'),
    'from' => env('KUDI_SMS_FROM'),
  ],

];
