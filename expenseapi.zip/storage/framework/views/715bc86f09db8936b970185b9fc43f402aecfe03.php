<!DOCTYPE html>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
     <head>
          <meta charset="utf-8">
          <title>ExpenseX privacy policy | Terms and conditions</title>
          <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;700&family=Patrick+Hand&display=swap" rel="stylesheet">
          <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
          <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
          <style>
             body {
                 font-family: 'Lato', sans-serif;
             }
         </style>
     </head>
     <body>
          <div class="sticky top-0 md:my-2 md:py-5 md:px-16 md:mb-4 bg-white z-50">
               <nav class="md:flex md:justify-between md:items-center">
                    <h1 class="text-secondary leading-9 tracking-wide text-2xl font-bold">ExpenseX Terms and Condition</h1>
                    <ul class="flex md:justify-end gap-4 text-lg">
                         <li> <a href="#header">Home</a>  </li>
                         <li> <a href="#about">About</a>  </li>
                         <li> <a href="#blog">Blog</a>  </li>
                         <li> <a href="#faq">FAQs</a>  </li>
                         <li> <a href="#waitlist" class="md:bg-primary md:px-6 md:py-3 text-white rounded-full">JOIN OUR WAITLIST</a>  </li>
                    </ul>
               </nav>
          </div>
     </body>
</html>
<?php /**PATH C:\wamp64\www\tryout\resources\views/privacy.blade.php ENDPATH**/ ?>