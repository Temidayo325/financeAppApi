This is the test email to confirm that it actualyl works
<?php /**PATH C:\wamp64\www\tryout\resources\views/mail/waitlist.blade.php ENDPATH**/ ?>